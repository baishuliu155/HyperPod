package moe.chenxy.hyperpods.ui.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ProgressBar
import android.widget.TextView
import moe.chenxy.hyperpods.R
import moe.chenxy.hyperpods.utils.miuiStrongToast.data.BatteryParams
import kotlin.math.abs

/**
 * LibrePods-style top Dynamic Island overlay for HyperPods.
 * Shows connection status + battery at the top of the screen.
 */
class IslandWindow(private val context: Context) {
    companion object {
        private const val TAG = "HyperPods-Island"
        private const val AUTO_CLOSE_MS = 4500L

        @Volatile
        private var instance: IslandWindow? = null

        @JvmStatic
        fun show(context: Context, deviceName: String, battery: BatteryParams) {
            Handler(Looper.getMainLooper()).post {
                try {
                    instance?.closeImmediate()
                    val island = IslandWindow(context.applicationContext)
                    instance = island
                    island.showInternal(deviceName, battery)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to show IslandWindow", e)
                }
            }
        }

        @JvmStatic
        fun dismiss() {
            Handler(Looper.getMainLooper()).post {
                instance?.close()
            }
        }
    }

    private val windowManager: WindowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    @SuppressLint("InflateParams")
    private val rootView: View =
        LayoutInflater.from(context).inflate(R.layout.island_window, null)

    private var params: WindowManager.LayoutParams? = null
    private var isClosing = false
    private val handler = Handler(Looper.getMainLooper())
    private var autoCloseRunnable: Runnable? = null

    private var initialY = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun showInternal(deviceName: String, battery: BatteryParams) {
        if (rootView.parent != null) return

        val title = rootView.findViewById<TextView>(R.id.island_title)
        val nameView = rootView.findViewById<TextView>(R.id.island_device_name)
        val batteryText = rootView.findViewById<TextView>(R.id.island_battery_text)
        val batteryProgress = rootView.findViewById<ProgressBar>(R.id.island_battery_progress)

        title.text = "Connected"
        nameView.text = deviceName.ifBlank { "AirPods" }

        val level = displayBatteryLevel(battery)
        if (level != null) {
            batteryText.text = "$level%"
            batteryProgress.progress = level
            batteryProgress.visibility = View.VISIBLE
            batteryText.visibility = View.VISIBLE
        } else {
            batteryText.text = "—"
            batteryProgress.progress = 0
        }

        val displayMetrics = context.resources.displayMetrics
        val width = (displayMetrics.widthPixels * 0.92).toInt()

        params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            // TYPE_APPLICATION_OVERLAY works when app has permission;
            // for Xposed system context, TYPE_SYSTEM_ALERT / TYPE_STATUS_BAR_SUB_PANEL may be needed.
            // Prefer overlay; fall back is handled by caller context.
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (12 * displayMetrics.density).toInt()
        }

        rootView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    cancelAutoClose()
                    initialY = rootView.translationY
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - initialTouchY
                    if (abs(dy) > 8 || isDragging) {
                        isDragging = true
                        // only allow drag upward to dismiss
                        rootView.translationY = (initialY + dy).coerceAtMost(0f)
                        rootView.alpha = (1f + rootView.translationY / 200f).coerceIn(0.3f, 1f)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging && rootView.translationY < -80f) {
                        close()
                    } else {
                        rootView.animate()
                            .translationY(0f)
                            .alpha(1f)
                            .setDuration(200)
                            .start()
                        scheduleAutoClose()
                    }
                    true
                }
                else -> false
            }
        }

        try {
            // enter from above
            rootView.translationY = -120f
            rootView.alpha = 0f
            windowManager.addView(rootView, params)

            rootView.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(380)
                .setInterpolator(OvershootInterpolator(1.1f))
                .start()

            scheduleAutoClose()
            Log.i(TAG, "Island shown for $deviceName level=$level")
        } catch (e: Exception) {
            Log.e(TAG, "addView failed (need SYSTEM_ALERT_WINDOW?): ${e.message}")
            instance = null
        }
    }

    private fun displayBatteryLevel(battery: BatteryParams): Int? {
        val left = battery.left
        val right = battery.right
        return when {
            left != null && left.isConnected && left.battery > 0 &&
                right != null && right.isConnected && right.battery > 0 ->
                minOf(left.battery, right.battery)
            left != null && left.isConnected && left.battery > 0 -> left.battery
            right != null && right.isConnected && right.battery > 0 -> right.battery
            else -> null
        }
    }

    private fun scheduleAutoClose() {
        cancelAutoClose()
        autoCloseRunnable = Runnable { close() }
        handler.postDelayed(autoCloseRunnable!!, AUTO_CLOSE_MS)
    }

    private fun cancelAutoClose() {
        autoCloseRunnable?.let { handler.removeCallbacks(it) }
        autoCloseRunnable = null
    }

    fun close() {
        if (isClosing) return
        isClosing = true
        cancelAutoClose()

        try {
            ObjectAnimator.ofFloat(rootView, View.TRANSLATION_Y, rootView.translationY, -160f).apply {
                duration = 280
                interpolator = DecelerateInterpolator()
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        closeImmediate()
                    }
                })
                start()
            }
            ObjectAnimator.ofFloat(rootView, View.ALPHA, rootView.alpha, 0f).setDuration(280).start()
        } catch (e: Exception) {
            closeImmediate()
        }
    }

    fun closeImmediate() {
        try {
            cancelAutoClose()
            if (rootView.parent != null) {
                windowManager.removeView(rootView)
            }
        } catch (_: Exception) {
        } finally {
            isClosing = false
            if (instance === this) instance = null
        }
    }
}
